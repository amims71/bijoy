<?php
$mysql_host='localhost';
$mysql_user='bijoy_1971';
$mysql_pass='Bijoy2013#';

$mysql_db='bijoy_2016';

if(!mysql_connect($mysql_host, $mysql_user, $mysql_pass)||!mysql_select_db($mysql_db)){
	die(mysql_error());
}

mysql_connect($mysql_host, $mysql_user, $mysql_pass);
	mysql_select_db($mysql_db);

?>